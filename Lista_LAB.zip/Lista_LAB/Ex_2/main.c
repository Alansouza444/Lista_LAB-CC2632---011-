#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int a ;
    int b ;
}XPTO;

void criaVetor (XPTO *v , int n){
    int i ;
    for (i =0; i<n ; i++){
        v[i].a = i%3;
        v[i].b = 100-i%5;
    }
}

void imprimeVetor (XPTO * v ,int n){
    int i ;
    for (i =0; i<n ; i++){
        printf ("a=%d b=%d\n",v[i].a, v[i].b) ;
    }
}


int porA(void * p1 , void * p2 ){
    XPTO* pp1 = p1 ;
    XPTO* pp2 = p2 ;
    return pp1->a < pp2->a ;
}

int porB(void * p1 , void * p2 ){
    XPTO *pp1 = p1 ;
    
    XPTO *pp2 = p2 ;
    return pp1->b < pp2->b ;
}

void merge(int *V,int ini,int meio,int fim) {
    int i = ini;
    int j = meio + 1;
    int k = 0;
    int aux[fim - ini + 1];
    
    while ((i <= meio) && (j <= fim)) {
        if (V[i] <= V[j]) {
            aux[k] = V[i];
            i++;
        }
        else {
            aux[k] = V[j];
            j++;
        }
        k++;
    }
    
    if (i <= meio)  {
        j = meio;
        while (j >= i) {
            V[fim - meio + j] = V[j];
            j--;
        }
    }
    
    for (i = 0;i < k;i++)
        V[ini + i] = aux[i];
    
    
}

void mergeSortR(int *V,int ini,int fim) {
    int meio;
    
    if (ini < fim) {
        meio = (ini + fim) / 2;
        if (ini < meio)
            mergeSortR(V,ini,meio);
        if ((meio + 1) < fim)
            mergeSortR(V,meio + 1,fim);
        
        merge(V,ini,meio,fim);
    }
}
void mergeSort(int *V,int n) {
    mergeSortR(V,0,n-1);
}
int main ( int argc , char * argv [ ] ) {
    
    
    XPTO v[10];
    criaVetor(v,10);
    mergeSortR(v, 10, 0);
    imprimeVetor (v,10);
    
    return 0 ;
    
}

