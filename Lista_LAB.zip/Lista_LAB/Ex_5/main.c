#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>

typedef struct {
    char nome[50];
    char email[30];
    char registro [10];
    char fone[20];
    float p1;
	float p2;
	float p3;
	float media;
    int op;
    
  } aluno;

void incluir (aluno *a){
   	FILE *arquivo;
   	float media;
   	int cont;
    	
	arquivo = fopen("aluno.txt", "w");
    		
   	if (arquivo == NULL){
		
		printf("\t\t\t\t\tErro no arquivo!\n");
	}
	
	else{
		do{
		
			fflush(stdin);
				printf("\n\tDigite o nome: ");
				gets(a->nome);	
			
			fflush(stdin);
				printf("\n\tDigite o tel: ");
				gets(a->fone);
			
			fflush(stdin);
				printf("\n\tDigite o e-mail: ");
				gets(a->email);
				
				printf("\n\tDigite o registro: ");
				gets(a->registro);
				
				printf("\n Digite a nota obtida na p1 : ");
				scanf("%f", &a->p1);
				printf("\n Digite a nota obtida na p2 : ");
				scanf("%f", &a->p2);
				puts("\n==================================================");
	
				media = 0.4*(a->p1) + 0.6*(a->p2);
				printf("\n Media =  %2.f\n", media);
	
				if(media >= 5.00){
				printf("\n\t\t Aluno de recuperecao!\n");
			}
	
				if (media < 5){
	    			if (a->p1>a->p2){
					printf("\n Digite a obtida na P3:\n");
           			scanf("%f", a->p3);
					media = ((a->p1)*0.4+(a->p3)*0.6);
					printf("\n A media foi:%.2f\n",media);

				}else{
           		 printf("\n Digite a nota obtida na P3:\n");
           		 scanf("%f", &a->p3);
			 		media = ((a->p2)*0.6+ (a->p3)*0.4);
			 		printf("\n Media = %.2f\n" ,media);

		}
	
				if(media >= 5.00){
					printf("\n\t\t Aluno Aprovado!\n");
	}
				else{
					printf("\n\t\t Aluno Reprovado\n");
	}
	
}
			
					fwrite(a, sizeof(aluno), 1, arquivo);
		      
			  		printf("\n\tDeseja procurar outro aluno?\n");
					printf("\n\t1 - Continuar \n");
					printf("\n\t0 - Sair\n");
					scanf("%d" ,&cont);
			
				}while(cont == 1);
				fclose(arquivo);
			
      }
    }
    

void listar(aluno *a){

	FILE* arquivo;
	
	
	arquivo = fopen("aluno.txt", "r");
	
	if (arquivo==NULL){
	
		printf("\n\tErro no arquivo\n");
		
	}
	else{
	
		while(fread(&a,sizeof(aluno),1,arquivo)==1){
			
			
			printf("\n\tNome: %s\n", a->nome);
			printf("\n\tTel: %s\n", a->fone);
			printf("\n\tE-mail: %s\n", a->email);
			printf("\n\tRegistro: %s\n", a->registro);
			printf("\Media = %.2f\n" ,a->media);
			
			printf("");
		}
	}
	fclose(arquivo);
	getch();
}

void consultar(aluno *a){
	FILE* arquivo;
	
	char procurado[100];
	
		
	arquivo = fopen("aluno.txt", "r");
	
	fflush(stdin);
	printf("\n\tDigite o nome que deseja pesquisar: ");

	gets(procurado);
		
	while(fread(&a,sizeof(aluno),1,arquivo)==1){
		
		if (strcmp(procurado,a->nome)==0){
			
			
			printf("\n\tNome: %s\n", a->nome);
			printf("\n\tTel: %s\n", a->fone);
			printf("\n\tE-mail: %s\n", a->email);
			printf("\n\tRegistro: %s\n", a->registro);
			printf("\nMedia = %.2f\n" ,a->media);
			
			
			}
		
	}
	
	fclose(arquivo);
	getch();
}

void excluir(aluno *a){
	FILE* arquivo;
	FILE* farquivo;
	
	char procurado[1000];

	arquivo = fopen("aluno.txt", "r");
	farquivo = fopen("aluno_novo.txt", "w");

	if (arquivo ==NULL || farquivo == NULL){
		printf("\n\tErro no arquivo\n");
		return;
	}
	else{
		
		fflush(stdin);
		listar(a);
		
		printf("\n\tDigite o nome que deseja excluir: ");
		gets(procurado);

	while(!feof(arquivo)){
        fread(&a,sizeof(aluno),1,arquivo);
			
			if (strcmp(procurado,a->nome)==0){
                
                fwrite(NULL, sizeof(aluno), 1, farquivo);
				printf("\n\tCadastro %s excluido!\n",a->nome);
				break;
                
                
			}else{
			   
			    if(feof(arquivo)) break;
                fwrite(a, sizeof(aluno),1,farquivo);
            }
		}
	}

	fclose(arquivo);
	fclose(farquivo);

    remove("aluno_x.txt");
  	rename("aluno.txt", "aluno_x.txt");
  	rename("aluno_novo.txt", "aluno.txt");
	getch();
}



int main(){
	setlocale(LC_ALL,"Portuguese");
 	aluno *a = malloc(sizeof(aluno));
	 int op;
 	
	do{
		
	    puts("\n\t\t\t\t\t\t\tLISTA DE ALUNOS\n");
	    puts("\n\tMenu Diario\n");
	    puts("\t1 - Incluir alunos\n");
	    puts("\t2 - Listar alunos\n");
	    puts("\t3 - Consultar alunos\n");
	    puts("\t4 - Excluir alunos\n");
	    puts("\t5 - Sair\n");
	    printf("\n\tDigite uma opcao: ");
	    scanf("%d",&op);
		
			switch(op){
			
    	
		      case 1:
		      	incluir(a); 
		      	break;
		      
		      case 2:
		      	listar(a); 
		      	break;
		      
		      
		      case 3: 
		      	consultar(a); 
		      	break;
		      
		      case 4: 
		      	excluir(a); 
		      	break;
		      
		      case 5: 
		        printf("\n\t\t\t\t\t\t\tFinalizando\n");
				
				break;
		        
		      default:
		    
			  	printf("\n\t\t\t\tTente novamente!\n\t\t");
			  	getch();
		      	break;
		  	}	

  }while(op!=5);

  return 0;
}
