#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct MOD {
    int linha;
    int coluna;
    double valor;
} MOD;


MOD ** matriz_criar( int ncolunas, int nlinhas )
{
    int i = 0;
    
  
    MOD ** c = (MOD**) malloc( nlinhas * sizeof(MOD*) );
    
    for( i = 0; i < nlinhas; i++ )
        c[i] = (MOD*) malloc( ncolunas * sizeof(MOD) );
    
    return c;
}

void matriz_destruir( MOD ** c, int nlinhas ){
    int i = 0;
    
    for( i = 0; i < nlinhas; i++ )
        free(c[i]);
    
    free(c);
}

void matriz_preencher( MOD ** m, int ncolunas, int nlinhas ){
    int y = 0;
    int x = 0;
    
    for( y = 0; y < nlinhas; y++ )
        for( x = 0; x < ncolunas; x++ )
        
            m[y][x].valor = rand() / ((float)RAND_MAX);
}

void matriz_exibir( MOD ** m, int ncolunas, int nlinhas ){
    int y = 0;
    int x = 0;
    
    for( y = 0; y < nlinhas; y++ ){
        for( x = 0; x < ncolunas; x++ )
        
            printf( "%0.2f ", m[y][x].valor );
        printf("\n");
    }
}

int main( void ){
    int ncolunas = 10;
    int nlinhas = 20;
    
    
    MOD ** m = matriz_criar( ncolunas, nlinhas );
    matriz_preencher( m, ncolunas, nlinhas );
    matriz_exibir( m, ncolunas, nlinhas );
    matriz_destruir( m, nlinhas );
    return 0;
}
