#include <stdlib.h>
#include <stdio.h>




int* criaVetor(int n){
	
	int *r = malloc(sizeof(int) * n);
	return r;
}

void preenche_vetor(int* v, int n){

	int i;
	for(i=0;i<n; i++){
		v[i] = (i*2+5);
	}
}

void imprime_vetor(int* v, int n){
	int i;
	for(i=0;i<n;i++){
		printf("%-3d ", v[i]);
	}
	puts("");
}

int busca(int* v, int n, int num){
	int i;
	
	for(i=0; i<n && v[i] <= num; i++){ 
		if(v[i] == num)
		    return v[i];
	}
	return -1;
}

void destroi_vetor(int *v, int n ){
	
	int i;
	for(i=0;i<n; i++){
		free(v);		
	}

}

int main(int argc, char *argv[]) 
{
	int *v = criaVetor(20);
	int n;
	int num;
	
	printf("Digite o tamanho do vetor :");
	scanf("%d", &n);
	
	preenche_vetor(v, n);
	imprime_vetor(v, n);

	printf("Digite o numero que deseja procurar do vetor :");
	scanf("%d", &num);
	
	int bc = busca(v, n, num);
	destroi_vetor(v , n); 
	
	printf("%d\n", bc);
	
	
	
	system("pause");	
	return 0;
}
